# Daily Tech & AI News Digest

Fetches top tech and AI headlines from Reuters, CNBC, and FT every weekday at **2:00 AM SAST**, summarises them using Claude in institutional equity research style, and emails the digest to you.

---

## What you need (one-time setup, ~15 minutes)

1. A free [GitHub](https://github.com) account
2. A personal [Anthropic API key](https://console.anthropic.com) (~USD3–5/month)
3. A Gmail address + App Password (see step 3 below)

---

## Step-by-step setup

### Step 1 — Create a GitHub repository

1. Log in to [github.com](https://github.com)
2. Click **New repository** (top right, green button)
3. Name it: `daily-digest`
4. Set it to **Private**
5. Click **Create repository**

---

### Step 2 — Upload the files

Upload all three files maintaining this exact folder structure:

```
daily-digest/
├── requirements.txt
├── scripts/
│   └── digest.py
└── .github/
    └── workflows/
        └── daily-digest.yml
```

The easiest way:

1. On your new repo page, click **Add file → Upload files**
2. Upload `requirements.txt` and `scripts/digest.py` first
3. Then create the workflow file by clicking **Add file → Create new file**
4. Type the path as: `.github/workflows/daily-digest.yml`
5. Paste the contents of `daily-digest.yml` into the editor
6. Click **Commit changes**

---

### Step 3 — Create a Gmail App Password

> This lets the script send email via your Gmail without using your real password.

1. Go to your Google Account: [myaccount.google.com](https://myaccount.google.com)
2. Click **Security** in the left menu
3. Under "How you sign in to Google", enable **2-Step Verification** if not already on
4. Go back to Security, scroll down to **App passwords** (may need to search for it)
5. Click **App passwords**
6. Under "Select app" choose **Mail**, under "Select device" choose **Other** → type "GitHub Digest"
7. Click **Generate** — copy the 16-character password shown (no spaces)

---

### Step 4 — Add your secrets to GitHub

1. In your GitHub repo, go to **Settings → Secrets and variables → Actions**
2. Click **New repository secret** for each of the three below:

| Secret name | Value |
|---|---|
| `ANTHROPIC_API_KEY` | Your key from console.anthropic.com (starts with `sk-ant-...`) |
| `GMAIL_ADDRESS` | Your full Gmail address (e.g. `you@gmail.com`) |
| `GMAIL_APP_PASSWORD` | The 16-character app password from Step 3 |

---

### Step 5 — Test it manually

1. Go to your repo → **Actions** tab
2. Click **Daily Tech & AI Digest** in the left panel
3. Click **Run workflow → Run workflow** (green button)
4. Watch it run — should take 2–3 minutes
5. Check your inbox at `mdenobrega19@gmail.com`

---

## Schedule

Runs automatically at **2:00 AM SAST (midnight UTC)**, Monday to Friday.

You can also trigger it manually any time via the Actions tab.

---

## Estimated cost

| Item | Cost |
|---|---|
| GitHub Actions | Free (well within free tier) |
| Claude API (est. 12 articles/day) | ~USD3–5/month |
| Gmail sending | Free |

---

## Customising

**Add/remove companies to track:** edit `COMPANY_KEYWORDS` in `scripts/digest.py`

**Add/remove news sources:** edit the `FEEDS` list in `scripts/digest.py`

**Change the schedule:** edit the `cron` line in `.github/workflows/daily-digest.yml`
- Format: `"minute hour * * days"` where days: 1=Mon, 5=Fri
- Current: `"0 0 * * 1-5"` = midnight UTC (2am SAST) weekdays

**Change max articles:** edit `MAX_ARTICLES` in `scripts/digest.py`

---

## Troubleshooting

**No email received:** Check the Actions tab for error logs — most common issues are incorrect secret names or Gmail app password not set up correctly.

**Empty digest:** The filter may have been too strict that day. Check the Actions log — it prints how many articles were found.

**Gmail auth error:** Re-generate the app password (Step 3) and update the secret.
